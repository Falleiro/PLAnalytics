# World Cup Analytics — Fase 4 (CRISP-DM): Relatório dos Modelos Testados

**Autor:** Caio Falleiro dos Santos
**Entrega:** 4 — *Relatório dos Modelos Testados*
**Metodologia:** CRISP-DM — etapa *Modeling*

---

## 1. Do que se trata

Esta é a **Fase 4 (Modeling)** do projeto de previsão de resultados da Copa do Mundo 2026.
Partindo da base limpa entregue na Fase 3 (`worldcup_dataset_clean.csv`), esta etapa **constrói a
ABT preditiva** (1 linha por perspectiva de seleção, *leakage-safe*), **treina e compara quatro
modelos** de classificação multiclasse {Vitória, Empate, Derrota} e **justifica a escolha do modelo
final** que abastece as previsões.

O objetivo central da entrega é responder, com evidência: **qual modelo usar e por quê.** Por isso o
notebook não treina um único modelo — ele **compara 4** sob exatamente as mesmas condições, mede as
métricas, valida no tempo e registra a decisão (e como ela mudou ao longo da experimentação).

## 2. Conteúdo do pacote

```
.
├── 04_modelagem.ipynb                # NOTEBOOK PRINCIPAL desta entrega
├── data/
│   └── worldcup_dataset_clean.csv    # ENTRADA — base limpa + features (saída da Fase 3)
├── requirements.txt                  # dependências Python
└── README.md                         # este arquivo
```

> O notebook localiza o CSV automaticamente (procura em `data/` dentro do pacote ou em
> `../output/` no repositório), então roda nos dois layouts sem ajuste.

## 3. O que o notebook faz (roteiro)

1. **Carga da base limpa** e diagnóstico de vazamento de dados (*data leakage*) — por que só
   podemos usar informação disponível **antes** do apito inicial.
2. **Engenharia de features pré-jogo (leakage-safe):**
   - **Forma recente (N=10)** de cada métrica, com `shift(1)` (exclui a própria partida);
   - **Elo dinâmico** atualizado jogo a jogo, com vantagem de mando **zerada em campo neutro**
     (Copa, Copa América, etc.);
   - **Head-to-Head** (win rate e gols dos últimos 5 confrontos diretos);
   - ranking FIFA, dias de descanso e as **diferenças orientadas pela ótica do time** (`diff_*`).
3. **ABT longa — duas linhas por jogo** (a ótica de cada seleção): o alvo fica **naturalmente
   balanceado** (~39% V / 21% E / 39% D), em vez do viés de mando da base original (~58% V).
4. **Split temporal** (treinar no passado, testar no futuro) + **baselines** (régua): frequência
   por perspectiva e ótica do mandante.
5. **Comparação multi-modelo** — Logistic Regression, Random Forest, HistGradientBoosting e
   XGBoost, todos **calibrados** (`sigmoid` + `TimeSeriesSplit`) e treinados com o **mesmo**
   `sample_weight` (importância da competição).
6. **Métricas e diagnósticos:** tabela e gráficos (log-loss, accuracy, F1 macro), **matrizes de
   confusão**, **curvas de calibração**, **importância por permutação** e **validação temporal
   (5 blocos)**.
7. **Decisão do Modelo (model card):** quadro automático que ranqueia os modelos e declara o
   escolhido, com critérios e o **histórico da decisão**.

## 4. Como executar

Pré-requisito: **Python 3.10+**.

```bash
# 1) (opcional) criar ambiente virtual
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# 2) instalar dependências
pip install -r requirements.txt

# 3) abrir o notebook
jupyter notebook 04_modelagem.ipynb
```

No Jupyter, execute as células em ordem (menu **Cell → Run All**).

> **Sem Jupyter?** Também é possível rodar tudo de uma vez pelo terminal:
> ```bash
> jupyter nbconvert --to notebook --execute --inplace 04_modelagem.ipynb
> ```

## 5. Principais resultados desta fase

**Os 4 modelos batem o baseline** (log-loss de frequência por perspectiva ≈ 1.066). Comparação no
conjunto de teste (split temporal) e na validação temporal de 5 blocos:

| Modelo | log-loss teste | log-loss por partida | CV temporal (média ± std) | accuracy |
|---|---:|---:|---:|---:|
| **Random Forest** ✅ | **0.831** | **0.830** | **0.874 ± 0.047** | 0.657 |
| Logistic Regression | 0.850 | 0.850 | 0.881 ± 0.054 | 0.642 |
| XGBoost | 0.854 | 0.853 | 0.880 ± 0.038 | 0.631 |
| HistGradientBoosting | 0.860 | 0.862 | 0.880 ± 0.028 | 0.640 |

**Modelo escolhido: Random Forest calibrado** — menor log-loss de teste **e** menor log-loss médio
na validação temporal, com probabilidades bem calibradas.

### Como a decisão evoluiu (parte importante do relatório)

A escolha **mudou** durante a experimentação, em torno de uma única decisão: como pesar as amostras.

- **1ª versão — com balanceamento de classe** (`sample_weight = balanced × importância`): nesse
  cenário o **XGBoost liderava** o log-loss. **Porém**, o `balanced` força as 3 classes a ~33% cada,
  **inflando o empate** de ~21% (taxa real) para ~35% — um resultado **raro** no futebol. O modelo
  passava a "achar empate demais" e a **calibração das probabilidades piorava**. Como o produto final
  são *probabilidades*, isso é um defeito sério.
- **2ª versão — sem balanceamento** (`sample_weight = só importância`): com o empate de volta à sua
  taxa-base real, **o Random Forest passou a frente** do XGBoost — tanto no teste quanto na CV
  temporal. É a configuração final, adotada também no código de produção (`predict_match.py`).

## 6. Observação metodológica (anti-vazamento e calibração)

- **Anti-vazamento:** todas as features usam apenas o histórico **anterior** a cada jogo
  (`shift(1)` + médias móveis, Elo em passada sequencial). Estatísticas medidas *durante* a partida
  jamais entram como preditor — usá-las seria prever o jogo com o placar do próprio jogo.
- **Calibração acima de acurácia:** a métrica-alvo é **log-loss** (qualidade das probabilidades),
  não a acurácia bruta. Por isso evitamos o rebalanceamento artificial de classes, que melhoraria
  números isolados mas degradaria a confiabilidade das probabilidades — o que de fato é entregue ao
  usuário final (P(vitória) / P(empate) / P(derrota) de cada confronto).
