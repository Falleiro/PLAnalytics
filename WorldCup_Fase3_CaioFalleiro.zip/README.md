# World Cup Analytics — Fase 3 (CRISP-DM): Preparação e Análise Estatística dos Dados

**Autor:** Caio Falleiro dos Santos
**Entrega:** 3 — *Script de Preparação dos Dados e Análises Estatísticas dos Dados*
**Metodologia:** CRISP-DM — etapa *Data Preparation*

---

## 1. Do que se trata

Esta é a **Fase 3 (Data Preparation)** do projeto de previsão de resultados da Copa do Mundo
2026. Partindo da base bruta entregue na Fase 2 (1 linha por partida, extraída do SofaScore),
esta etapa faz o **tratamento dos dados**, **constrói as features de forma** e produz uma
**base limpa, com features e documentada**, pronta para a Modelagem (Fase 4) — junto com as
**análises estatísticas** (descritivas e inferenciais) exigidas.

O que foi feito **nesta Fase 3** (detalhado na Seção 3):
- tratamento de valores nulos por causa, com flags de qualidade;
- construção das **features de forma** (médias móveis *leakage-safe*);
- **análises estatísticas** descritivas e inferenciais (testes de hipótese);
- tratamento de outliers e exportação da base limpa.

## 2. Conteúdo do pacote

```
.
├── 03_preparacao_e_analise.ipynb     # NOTEBOOK PRINCIPAL desta entrega
├── data/
│   ├── worldcup_dataset.csv          # ENTRADA  — base bruta (1.138 partidas × 102 colunas)
│   └── worldcup_dataset_clean.csv    # SAÍDA    — base tratada + features (1.138 × 143)
├── requirements.txt                  # dependências Python
└── README.md                         # este arquivo
```

> O `worldcup_dataset_clean.csv` já vem incluído como **resultado esperado**. Ele é
> **regenerado** automaticamente ao executar o notebook (não é preciso confiar no arquivo).

## 3. O que o notebook faz (roteiro)

1. **Carga e tipagem** — leitura do CSV, conversão de datas, separação entre colunas de
   contexto (IDs, datas, texto) e colunas numéricas de *feature*.
2. **Análise descritiva (EDA)** — balanceamento do alvo, histogramas, `describe()`, matriz de
   correlação e detecção de pares redundantes.
3. **Diagnóstico e tratamento de valores nulos** — classificados **por causa** (sem fonte,
   ausência = zero, MNAR por competição, contexto textual), com tratamento específico para cada
   grupo e **flags de qualidade** (`has_team_stats`, `has_player_stats`, `has_xg`, `has_ranking`).
4. **Construção de features de forma (Seção 3.5)** — para cada seleção, a **média móvel dos
   últimos 5 jogos** de cada métrica (pontos, gols, xG/xGA, posse, finalizações, rating, etc.).
   Calculada de forma ***leakage-safe*** com `shift(1)` (exclui a própria partida) + `rolling(5)`,
   gerando `home_form_*`, `away_form_*` e as **diferenças `form_diff_* = mandante − visitante`**
   — os preditores realmente disponíveis **antes** de cada jogo.
5. **Análise inferencial (testes de hipótese)** sobre as **features pré-jogo**:
   - **Kruskal-Wallis** (não-paramétrico) — quais features pré-jogo *separam* W/D/L.
   - **Qui-quadrado de independência** — relação entre favoritismo no ranking e resultado.
6. **Diagnóstico e tratamento de outliers** — distinguindo erro de medição (corrigido) de jogo
   legítimo atípico (mantido); winsorização opcional.
7. **Exportação** da base limpa + **tabela de decisões** registrando cada escolha e justificativa.

## 4. Como executar

Pré-requisito: **Python 3.10+**.

```bash
# 1) (opcional) criar ambiente virtual
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# 2) instalar dependências
pip install -r requirements.txt

# 3) abrir o notebook
jupyter notebook 03_preparacao_e_analise.ipynb
```

No Jupyter, execute as células em ordem (menu **Cell → Run All**). O notebook localiza o CSV de
entrada automaticamente (procura em `data/` dentro do pacote) e grava o
`worldcup_dataset_clean.csv` na mesma pasta.

> **Sem Jupyter?** Também é possível rodar tudo de uma vez pelo terminal:
> ```bash
> jupyter nbconvert --to notebook --execute --inplace 03_preparacao_e_analise.ipynb
> ```

## 5. Principais resultados desta fase

- Base: **1.138 partidas × 102 colunas** brutas → base final com **143 colunas** (após drops,
  flags, features de forma e variáveis winsorizadas).
- Alvo **desbalanceado** (~58% vitória do mandante) → na Fase 4 usar `log-loss`, `F1 macro` e
  balanceamento de classes.
- **Features de forma construídas e validadas:** das **14 features pré-jogo** testadas
  (`form_diff_*` + `rank_diff`), **as 14 são estatisticamente significativas** (Kruskal-Wallis,
  p < 0,05) — lideradas por `rank_diff`, `form_diff_possession` e `form_diff_points`. Ou seja, a
  **forma recente** e a **força relativa** das seleções realmente separam o resultado *antes* do
  jogo. **835** partidas têm forma calculável nos dois lados (`has_form`).
- O **ranking** tem efeito real (qui-quadrado, p ≈ 2,5e-04): mandante favorito vence **63,7%**
  das vezes contra **52,1%** quando o visitante é o favorito.
- Tratamento de nulos guiado por **causa**, preservando preditores de alto valor (xG/ranking)
  com flags em vez de descartá-los.

## 6. Observação metodológica (anti-vazamento)

Estatísticas medidas *durante* a partida (posse, finalizações, xG daquele jogo) só existem
**depois** do apito final — usá-las para prever o próprio jogo seria **vazamento de dados** e,
num teste de significância, daria resultado quase tautológico. Por isso a análise inferencial
(Seção 4.4) e a modelagem usam apenas as **features de forma** (`form_*` / `form_diff_*`),
construídas com médias móveis das partidas **anteriores** de cada seleção. As mesmas colunas
alimentam a Fase 4 (Modelagem).
